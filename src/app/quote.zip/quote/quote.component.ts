import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LocalStorage } from '@ngx-pwa/local-storage';
import {Router, ActivatedRoute} from "@angular/router";
import { Select2OptionData } from 'ng2-select2';
import carjson from './twowheeler.json';
import rtojson from './rto_master.json';
declare var $: any;

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['../../assets/quote/css/style.css','../../assets/quote/css/main.css'],
  //encapsulation : ViewEncapsulation.None
})
export class QuoteComponent implements OnInit {
	
	
	public exampleData: Array<Select2OptionData>;
	brandText: string = 'Brand';
	modelText: string = 'Model';
	fuelText: string = 'Fuel';
	variantText: string = 'Variant';
	registrationText: string = 'Registration';
	bikeText: string = '';
	
	form_brand: string = "0";
	form_model: string = "0";
	form_fuel: string = "0";
	form_variant: string = "0";
	form_rto_id: string = "0";
	form_rto_code: string = "0";
	form_reg_year: string = "2019";
	form_car: string = "0";
	
	twJson: any;
	rtoJson: any;
	quoteJson: any;
	totalBrandList: any;
	topBrandList: any;
	totalModelList: any;
	topModelList: any;
	totalFuelList: any;
	totalVariantList: any;
	topVariantList: any;
	totalRTOList: any;
	quoteSubmitted: any;
	quoteForm: FormGroup;
	
	
	constructor(public fb: FormBuilder,protected localStorage: LocalStorage,private router: Router,private route:ActivatedRoute){
		
	}
	
	ngOnInit() {
		this.quoteSubmitted=false;
		this.quoteForm = this.fb.group({
			custPhone: ['',[Validators.required,Validators.pattern(/^\d{10}$/)]],
			custEmail: ['',[Validators.required,Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/)]],
		});
		this.rtoJson=rtojson;
		this.twJson=carjson;
		this.get_brand();
		this.get_top_brand();
		this.get_rto_list();
		
		$(".fa-long-arrow-right").hide();
		$('input').attr('autocomplete', 'off');
		$(".close-gb").click(function() {
			$(this).parent('div.gb-modal').hide();
		});
		if ($(window).width() < 767) {
			$(".financer-desktop").hide();
			$('.select-mobile,.select2-selection__arrow').click(function() {
				var curr_id=$(this).attr("id");
				var curr=this;
				$(this).closest("div").find(".gb-modal").show();
				$(".navbar-full,#footer_area").hide();
				$("html, body").animate({
					scrollTop: 0
				}, 600);
				$(".wrap-contact100").removeClass("pull-right");
				$(this).closest("div").find("select").on("select2:select", function(evt) {
					var optionValue = evt.params.data.text;
					$(curr).closest("div").find(".gb-modal").closest(".gb-modal").hide();
					$("#"+curr_id).val(optionValue);
					$(".wrap-contact100").addClass("pull-right");
				});
			}).change();
		}
		$("#step1_form,#footer_area").removeClass('hide-me');
	}
	get f() { return this.quoteForm.controls; }
	goToTab(id)
	{
		$('#carouselExampleCaptions').carousel(parseInt(id));
	}
	editDetail()
	{
		this.localStorage.getItem('quoteJson').subscribe((data) => {
			var quoteJson=data;
			this.brandChanged(quoteJson.bike_id);
			console.log(quoteJson);
			this.form_rto_id = quoteJson.rto_id;
			this.form_rto_code = quoteJson.rto_code;
		});
		
	}
	brandChanged(car_id)
	{
		$('#carouselExampleCaptions').carousel(4);
		var filter_tw_list : any;
		this.twJson.forEach(el => {
			if(el.id==car_id)
			{
				filter_tw_list=el;
			}
		});
		this.bikeText= filter_tw_list.full_name;
		this.brandText= filter_tw_list.brand_name;
		this.modelText= filter_tw_list.model_name;
		this.fuelText= filter_tw_list.fuel_type_text;
		this.variantText= filter_tw_list.variant_name;
		this.registrationText= 'Registration';
		
		this.form_brand = filter_tw_list.brand_code;
		this.form_model = filter_tw_list.model_code;
		this.form_fuel = filter_tw_list.fuel_type;
		this.form_variant = filter_tw_list.variant_code;
		this.form_rto_id = "0";
		this.form_rto_code = "0";
		this.form_car = filter_tw_list.id;
		
		this.get_model(this.form_brand);
		this.get_top_model(this.form_brand);		
		this.get_variant(this.form_model,this.form_fuel);
		this.get_top_variant(this.form_model,this.form_fuel);
		this.get_fuel(this.form_model);
	}
	get_brand()
	{
		var totalBrandListFilter=[];
		var output: any;
		output={"id":0,"text":"Not in the list? Find your car's brand here"};
		totalBrandListFilter.push(output);
		this.twJson.forEach(el => {
			output={"id":el.id,"text":el.full_name};
			totalBrandListFilter.push(output);
		});
		this.totalBrandList=totalBrandListFilter;
		
		this.route.queryParams.subscribe(params => {
			if(params.edit=="Y")
			{
				this.editDetail();
			}
		});
	}
	
	get_rto_list()
	{
		
		var totalRTOListFilter=[];
		var output: any;
		output={"id":0,"text":"Select RTO (e.g. MH02 or Mumbai)"};
		totalRTOListFilter.push(output);
		this.rtoJson.forEach(el => {
			output={"id":el.id,"text":el.rto_code+" "+el.city_name};
			totalRTOListFilter.push(output);
		});
		this.totalRTOList=totalRTOListFilter;
		console.log(this.totalRTOList);
	}
	get_top_brand()
	{
		var filter_brand=[];
		this.twJson.forEach(el => {
			if(el.is_popular=='1')
			{
				filter_brand.push(el);
			}
		});
		this.topBrandList=filter_brand;
		//console.log(this.topBrandList);
	}
	
	brandTapped(event,brand_text,brand_val)
	{
		if(brand_val!="0" && typeof brand_val !== 'undefined' )
		{
			$('#carouselExampleCaptions').carousel(1);
			this.brandText= brand_text;
			this.modelText= 'Model';
			this.fuelText= 'Fuel';
			this.variantText= 'Variant';
			this.registrationText= 'Registration';
			
			this.form_brand = brand_val;
			this.form_model = "0";
			this.form_fuel = "0";
			this.form_variant = "0";
			this.form_rto_id = "0";
			this.form_rto_code = "0";
			this.form_car = "0";
			
			this.get_model(brand_val);
			this.get_top_model(brand_val);
		}
		
		
	}
	get_model(brand_val)
	{
		var filter_model=[];
		this.twJson.forEach(el => {
			if(el.brand_code==brand_val)
			{
				filter_model[el.model_code]=el;
			}
		});
		
		var finalModelList=[];
		var output: any;
		output={"id":0,"text":"Not in the list? Find your car's model here"};
		finalModelList.push(output);
		Object.keys(filter_model).forEach(function (key) {
			var el=filter_model[key];
			output={"id":el.model_code,"text":el.model_name};
			finalModelList.push(output);
		});
		this.totalModelList=finalModelList;
	}
	get_top_model(brand_code)
	{
		var filter_model=[];
		
		this.twJson.forEach(el => {
			if(el.brand_code==brand_code )
			{
				filter_model[el.model_code]=el;
			}
			
		});
		
		var finaltopModelList=[];
		var i=1;
		Object.keys(filter_model).forEach(function (key) {
			if(i<=12)
			{
				var el=filter_model[key];
				finaltopModelList.push(el);
				i++;
			}
		});
		this.topModelList=finaltopModelList;
	}
	modelTapped(event,model_text,model_val)
	{
		
		if(model_val!="0" && typeof model_val !== 'undefined' )
		{
			$('#carouselExampleCaptions').carousel(2);
			this.get_fuel(model_val);
			if ($(window).width() < 767) 
			{
				this.form_model = model_val;
				this.form_fuel = "0";
				this.form_variant = "0";
				this.form_rto_id = "0";
				this.form_rto_code = "0";
				this.form_car = "0";
				
				this.modelText= model_text;
				this.fuelText= 'Fuel';
				this.variantText= 'Variant';
				this.registrationText= 'Registration';
				
				$("#model-container").find(".fa-long-arrow-right").show();
				$("#fuel-container").find(".fa-long-arrow-right").hide();
				$("#variant-container").find(".fa-long-arrow-right").hide();
				$("#registration-container").find(".fa-long-arrow-right").hide();
			}
			else
			{
				this.form_model = model_val;
				this.form_fuel = "0";
				this.form_variant = "0";
				this.form_rto_id = "0";
				this.form_rto_code = "0";
				this.form_car = "0";
				
				this.modelText= model_text;
				this.fuelText= 'Fuel';
				this.variantText= 'Variant';
				this.registrationText= 'Registration';
			}
		}
	}
	get_fuel(model_code)
	{
		var filter_fuel=[];
		this.twJson.forEach(el => {
			if(el.model_code==model_code)
			{
				filter_fuel[el.fuel_type]=el;
			}
		});
		var finalFilterFuel=[];
		Object.keys(filter_fuel).forEach(function (key) {
			var el=filter_fuel[key];
			if(key=="P")
			{
				el.fuel_logo="gasoline.png";
			}
			if(key=="D")
			{
				el.fuel_logo="gas-station.png";
			}
			if(key=="E")
			{
				el.fuel_logo="electric-station.png";
			}
			finalFilterFuel.push(el);
		});
		this.totalFuelList=finalFilterFuel;
		console.log(this.totalFuelList);
	}
	fuelTapped(event,fuel_type_text,fuel_type,model_code)
	{
		$('#carouselExampleCaptions').carousel(3);
		$('#model .main-tab div').css("margin-left", "12px");
		this.get_variant(model_code,fuel_type);
		this.get_top_variant(model_code,fuel_type);
		
		this.form_fuel = fuel_type;
		this.form_variant = "0";
		this.form_rto_id = "0";
		this.form_rto_code = "0";
		this.form_car = "0";
		
		this.fuelText= fuel_type_text;
		this.variantText= 'Variant';
		this.registrationText= 'Registration';
		
		$("#variant .top-model__item").removeClass('is-selected');
		$("#fuel-container").find(".fa-long-arrow-right").show();
		$("#variant-container").find(".fa-long-arrow-right").hide();
		$("#registration-container").find(".fa-long-arrow-right").hide();
	}
	get_variant(model_code,fuel_type)
	{
		var finalVariantList=[];
		var output: any;
		output={"id":0,"text":"Not in the list? Find your car's variant here"};
		finalVariantList.push(output);
		
		this.twJson.forEach(el => {
			if(el.model_code==model_code && el.fuel_type==fuel_type)
			{
				output={"id":el.id,"text":el.variant_name};
				finalVariantList.push(output);
			}
		});
		this.totalVariantList=finalVariantList;
		//console.log(this.totalVariantList);
	}
	get_top_variant(model_code,fuel_type)
	{
		var filter_variant=[];
		this.twJson.forEach(el => {
			if(el.model_code==model_code && el.fuel_type==fuel_type)
			{
				filter_variant.push(el);
			}
		});
		var final_filter_variant=[];
		var i=1;
		filter_variant.forEach(el => {
			if(i<=12)
			{
				final_filter_variant.push(el);
				i++;
			}
		});
		this.topVariantList=final_filter_variant;
		//console.log(this.topVariantList);
	}
	variantTapped(event,car_id)
	{
		if(car_id!="0" && typeof car_id !== 'undefined' )
		{
		this.brandChanged(car_id);
		}
	}
	rtoTapped(event,rto_code,rto_id)
	{
		if(rto_id!="0" && typeof rto_id !== 'undefined' )
		{
			$('#carouselExampleCaptions').carousel(5);
			this.form_rto_id = rto_id;
			this.form_rto_code = rto_code;
		}
	}
	filterRTO(city_id)
	{
		var filter_rto=[];
		var output :any;
		output={"id":0,"text":"Select RTO (e.g. MH02 or Mumbai)"};
		filter_rto.push(output);
		this.rtoJson.forEach(el => {
			if(el.city_id==city_id)
			{
				output={"id":el.id,"text":el.rto_code+" "+el.city_name};
				filter_rto.push(output);
			}
		});
		this.totalRTOList=filter_rto;
	}
	quoteSubmit() {
		this.quoteSubmitted = true;
		if (this.quoteForm.invalid) {
			return;
		}
		else
		{
			this.quoteJson={"brand_code":this.form_brand,
			"model_code":this.form_model,
			"fuel_type":this.form_fuel,
			"variant_code":this.form_variant,
			"rto_id":this.form_rto_id,
			"rto_code":this.form_rto_code,
			"reg_year":this.form_reg_year,
			"bike_id":this.form_car,
			"cust_email":this.quoteForm.value.custEmail,
			"cust_phone":this.quoteForm.value.custPhone,
			"bike_fullname":this.bikeText,
			"brand_name":this.brandText,
			"model_name":this.modelText,
			"fuel_name":this.fuelText,
			"variant_name":this.variantText,
			}
			this.localStorage.setItem('quoteJson', this.quoteJson).subscribe(() => {
				console.log("Local Storage: "+this.quoteJson);
				this.router.navigate(['/quote-compare']);
			});
		}
	}
	
}
